Param(
    	[Parameter(Mandatory = $true)]
    	[string] $AdminUsername
)

<# CSV Format's Below ####
Group
GroupName
Admins
--------------------------
User
FirstName,LastName,UserName,Password,Group1,Group2
A. Scott,Wright,ascott0,password,domain admins,administrators
john,cena,Jcena,password,users
#>

###################################################################################################
#
# PowerShell configurations
#

# NOTE: Because the $ErrorActionPreference is "Stop", this script will stop on first failure.
#       This is necessary to ensure we capture errors inside the try-catch-finally block.
$ErrorActionPreference = "Stop"

# Ensure we set the working directory to that of the script.
Push-Location $PSScriptRoot

###################################################################################################
#
# Handle all errors in this script.
#

trap
{
    # NOTE: This trap will handle all errors. There should be no need to use a catch below in this
    #       script, unless you want to ignore a specific error.
    $message = $error[0].Exception.Message
    if ($message)
    {
        Write-Host -Object "ERROR: $message" -ForegroundColor Red
    }
    
    # IMPORTANT NOTE: Throwing a terminating error (using $ErrorActionPreference = "Stop") still
    # returns exit code zero from the PowerShell script when using -File. The workaround is to
    # NOT use -File when calling this script and leverage the try-catch-finally block and return
    # a non-zero exit code from the catch block.
    Write-Host 'Artifact failed to apply.'
    exit -1
}

###################################################################################################
#
# Main execution block.
#

try
{
### Import our Group CSV File ###
$GroupList = Import-Csv ".\groups.csv"

#Add groups from CSV
foreach ($Groups in $GroupList){
$GroupName = $Groups.GroupName
NEW-LocalGroup -name $GroupName
Write-Host "Group $($GroupName) has been created or already existed."
}

### Import our User CSV File ###

$UserList = Import-Csv ".\users.csv"
#Add users from CSV
foreach ($User in $UserList){
	$FullName = $User.FirstName + " " + $User.LastName
    	$Pass = $User.Password
	$Password = ConvertTo-SecureString $Pass -AsPlainText -force
	$SAM = $User.UserName
	$GROUP1 = $User.Group1
	$GROUP2 = $User.Group2

	##Create User##
	New-LocalUser -Name $SAM -FullName "$FullName" -Password $Password
	Add-LocalGroupMember -Group $GROUP1 -Member $user.username
	if($GROUP2)
	{
	Add-LocalGroupMember -Group $GROUP2 -Member $user.username
	}
Write-Host "User: $SAM added to groups: $GROUP1 & $GROUP2"	
}
	Add-LocalGroupMember -Group Sage200Admins -Member $AdminUsername
}
finally
{
    Pop-Location
}
